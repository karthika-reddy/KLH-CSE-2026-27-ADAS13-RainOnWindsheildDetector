import cv2
import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from pathlib import Path
from pipeline import run_pipeline, WIPER_MAP

DATA = Path("C:/Users/gcreddy/Downloads/rain_windshield_detector_project_final/data")
RESULTS = Path("C:/Users/gcreddy/Downloads/rain_windshield_detector_project_final/results")
RESULTS.mkdir(exist_ok=True)

FID = 1595
LEVELS = ["no_rain", "light", "moderate", "heavy"]
LEVEL_TITLES = {"no_rain": "No Rain", "light": "Light Rain", "moderate": "Moderate Rain", "heavy": "Heavy Rain"}

fig, axes = plt.subplots(2, 4, figsize=(18, 9))

baseline = cv2.imread(str(DATA / "frames" / f"{FID}_no_rain.png"))

for col, level in enumerate(LEVELS):
    frame = cv2.imread(str(DATA / "frames" / f"{FID}_{level}.png"))
    res = run_pipeline(frame, baseline)

    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    axes[0, col].imshow(rgb)
    axes[0, col].set_title(f"Input: {LEVEL_TITLES[level]}", fontsize=12, fontweight="bold")
    axes[0, col].axis("off")

    overlay = rgb.copy()
    overlay[res.roi_mask > 0] = [255, 60, 60]
    blended = cv2.addWeighted(rgb, 0.6, overlay, 0.4, 0)
    axes[1, col].imshow(blended)
    color = {"No Rain": "tab:gray", "Light": "tab:blue", "Moderate": "tab:orange", "Heavy": "tab:red"}[res.level]
    axes[1, col].set_title(
        f"Detected: {res.level}  ({res.density_pct:.2f}%)\nWiper -> {res.wiper_signal}",
        fontsize=11, color=color, fontweight="bold"
    )
    axes[1, col].axis("off")

fig.suptitle("Rain-on-Windshield Detector — Pipeline Output Across Rain Intensities (Scene 1595)",
              fontsize=15, fontweight="bold", y=0.99)
plt.tight_layout(rect=[0, 0, 1, 0.96])
plt.savefig(RESULTS / "pipeline_demo_grid.png", dpi=130, bbox_inches="tight")
plt.close()
print("Saved pipeline_demo_grid.png")

# ---- accuracy / metrics summary chart ----
ev = json.load(open(RESULTS / "evaluation.json"))
rows = ev["rows"]

fig, axes = plt.subplots(1, 2, figsize=(13, 5))

order = ["No Rain", "Light", "Moderate", "Heavy"]
labels_true = [r["true_level"] for r in rows]
labels_pred = [r["pred_level"] for r in rows]
conf = np.zeros((4, 4), dtype=int)
idx = {l: i for i, l in enumerate(order)}
for t, p in zip(labels_true, labels_pred):
    conf[idx[t], idx.get(p, 0)] += 1

im = axes[0].imshow(conf, cmap="Blues")
axes[0].set_xticks(range(4)); axes[0].set_xticklabels(order, rotation=30)
axes[0].set_yticks(range(4)); axes[0].set_yticklabels(order)
axes[0].set_xlabel("Predicted level"); axes[0].set_ylabel("True level")
axes[0].set_title(f"Confusion Matrix — Level Classification\nAccuracy: {ev['accuracy']*100:.1f}% (17/20 frames)",
                   fontsize=12, fontweight="bold")
for i in range(4):
    for j in range(4):
        axes[0].text(j, i, conf[i, j], ha="center", va="center",
                     color="white" if conf[i, j] > conf.max()/2 else "black", fontsize=13)

metrics = ["Level\nAccuracy", "Pixel\nPrecision", "Pixel\nRecall", "Pixel\nIoU"]
values = [ev["accuracy"]*100, ev["mean_precision"]*100, ev["mean_recall"]*100, ev["mean_iou"]*100]
bars = axes[1].bar(metrics, values, color=["#2E86AB", "#2E86AB", "#F39C12", "#F39C12"])
axes[1].set_ylim(0, 105)
axes[1].set_ylabel("%")
axes[1].set_title("Detection & Classification Metrics\n(across 20 labeled frames, 5 real scenes x 4 rain levels)",
                   fontsize=12, fontweight="bold")
for b, v in zip(bars, values):
    axes[1].text(b.get_x() + b.get_width()/2, v + 2, f"{v:.1f}%", ha="center", fontweight="bold")

plt.tight_layout()
plt.savefig(RESULTS / "evaluation_summary.png", dpi=130, bbox_inches="tight")
plt.close()
print("Saved evaluation_summary.png")
