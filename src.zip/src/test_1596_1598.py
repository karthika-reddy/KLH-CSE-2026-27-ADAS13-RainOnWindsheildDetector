"""
Runs the existing, unmodified pipeline (src/pipeline.py) on two scenes that
were NOT part of the original pipeline_demo_grid.png (which only showed
scene 1595): scene 1596 and scene 1598. All 4 rain levels per scene are
tested, so combined with the original 1595 demo, this gives coverage across
3 of the 5 scenes in the dataset.

This script does not modify pipeline.py, evaluate.py, the original
visualize.py, or any file that was in the original zip -- it only adds new
output files (this script + its generated grid + log).

Outputs (written into results/):
  - pipeline_demo_grid_1596_1598.png
  - test_run_1596_1598.json
"""
import cv2
import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from pathlib import Path
from pipeline import run_pipeline

DATA = Path(__file__).resolve().parent.parent / "data"
RESULTS = Path(__file__).resolve().parent.parent / "results"
RESULTS.mkdir(exist_ok=True)

SCENES = [1596, 1598]           # the two new test scenes
LEVELS = ["no_rain", "light", "moderate", "heavy"]
LEVEL_TITLES = {"no_rain": "No Rain", "light": "Light Rain",
                "moderate": "Moderate Rain", "heavy": "Heavy Rain"}
COLOR = {"No Rain": "tab:gray", "Light": "tab:blue",
         "Moderate": "tab:orange", "Heavy": "tab:red"}

fig, axes = plt.subplots(len(SCENES) * 2, 4, figsize=(18, 9 * len(SCENES)))

run_log = []

for s, fid in enumerate(SCENES):
    baseline = cv2.imread(str(DATA / "frames" / f"{fid}_no_rain.png"))
    for col, level in enumerate(LEVELS):
        frame = cv2.imread(str(DATA / "frames" / f"{fid}_{level}.png"))
        res = run_pipeline(frame, baseline)

        run_log.append({
            "scene": fid,
            "level_true": LEVEL_TITLES[level],
            "level_pred": res.level,
            "density_pct": round(res.density_pct, 3),
            "wiper_signal": res.wiper_signal,
            "n_blobs": res.n_blobs,
            "correct": res.level == LEVEL_TITLES[level].replace(" Rain", "") if level != "no_rain" else res.level == "No Rain",
        })

        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        r0 = s * 2
        axes[r0, col].imshow(rgb)
        axes[r0, col].set_title(f"Scene {fid} — Input: {LEVEL_TITLES[level]}",
                                 fontsize=11, fontweight="bold")
        axes[r0, col].axis("off")

        overlay = rgb.copy()
        overlay[res.roi_mask > 0] = [255, 60, 60]
        blended = cv2.addWeighted(rgb, 0.6, overlay, 0.4, 0)
        axes[r0 + 1, col].imshow(blended)
        axes[r0 + 1, col].set_title(
            f"Detected: {res.level}  ({res.density_pct:.2f}%)\nWiper -> {res.wiper_signal}  |  blobs={res.n_blobs}",
            fontsize=10, color=COLOR[res.level], fontweight="bold")
        axes[r0 + 1, col].axis("off")

fig.suptitle("Rain-on-Windshield Detector — Test Run on Scenes 1596 & 1598",
             fontsize=15, fontweight="bold", y=0.995)
plt.tight_layout(rect=[0, 0, 1, 0.98])
plt.savefig(RESULTS / "pipeline_demo_grid_1596_1598.png", dpi=130, bbox_inches="tight")
plt.close()

with open(RESULTS / "test_run_1596_1598.json", "w") as f:
    json.dump(run_log, f, indent=2)

n_correct = sum(r["correct"] for r in run_log)
print(f"Saved pipeline_demo_grid_1596_1598.png and test_run_1596_1598.json")
print(f"Accuracy on these 8 frames: {n_correct}/{len(run_log)} ({100*n_correct/len(run_log):.1f}%)\n")
print(f"{'scene':<8}{'true':<10}{'pred':<10}{'density%':<10}{'wiper':<8}{'blobs'}")
for r in run_log:
    print(f"{r['scene']:<8}{r['level_true']:<10}{r['level_pred']:<10}{r['density_pct']:<10}{r['wiper_signal']:<8}{r['n_blobs']}")
