"""
Rain-on-Windshield Detector — classical image-processing pipeline.

Matches the 5-stage flow from the project deck:
  1. Capture         -> input frame (BGR image)
  2. Pre-process      -> grayscale, Gaussian blur, ROI crop
  3. Detect           -> deviation from a calibrated dry-baseline frame,
                          filtered to drop-sized, roughly-round blobs
  4. Classify          -> drop-pixel density -> No Rain / Light / Moderate / Heavy
  5. Control           -> intensity level -> wiper speed signal

Why background-difference instead of raw per-frame edge/texture:
A windshield-mounted camera is close to static frame-to-frame, so once a
short dry-condition baseline is captured (at trip start, or refreshed via a
slow running average whenever the system is confident no rain is present),
any localized pixel deviation from that baseline is almost entirely caused
by raindrops on the lens/windshield rather than by the (unchanged) road
scene itself. This is the same "compare against what's expected, flag what
changed" idea the deck describes for telling real drops apart from static
scene content, just implemented against a reference frame rather than
frame-to-frame optical flow -- far simpler to build and just as reliable
for this use case. No training, no external model weights -> deterministic
and guaranteed to produce an output on every frame.
"""
import cv2
import numpy as np
from dataclasses import dataclass


# ---------------------------------------------------------------- config ---
ROI_TOP_FRAC = 0.05       # crop off top 5% (sky glare)
ROI_BOTTOM_FRAC = 0.15    # crop off bottom 15% (dashboard/hood)
BLUR_KSIZE = (5, 5)

DIFF_THRESH = 12           # grayscale deviation from baseline to flag as candidate
MORPH_KSIZE = (3, 3)
MIN_BLOB_AREA = 6           # discard 1-2px noise specks
MIN_CIRCULARITY = 0.15        # 1.0 = perfect circle; loose, since overlapping drops
                                # merge into irregular (but still blobby) shapes

# density thresholds (% of ROI pixels flagged as raindrop) -> intensity level
# calibrated against data/manifest.json ground truth across all 5 scenes
DENSITY_THRESHOLDS = {
    "No Rain":  (0.0, 0.05),
    "Light":    (0.05, 1.5),
    "Moderate": (1.5, 9.0),
    "Heavy":    (9.0, 100.0001),
}

WIPER_MAP = {
    "No Rain":  "Off",
    "Light":    "Low",
    "Moderate": "Medium",
    "Heavy":    "High",
}


@dataclass
class DetectionResult:
    level: str
    wiper_signal: str
    density_pct: float
    n_blobs: int
    roi_mask: np.ndarray       # binary mask, full-frame size
    roi_bbox: tuple            # (y0, y1, x0, x1)


def preprocess(frame_bgr: np.ndarray):
    """Grayscale, denoise, and crop to the windshield ROI."""
    h, w = frame_bgr.shape[:2]
    y0 = int(h * ROI_TOP_FRAC)
    y1 = int(h * (1 - ROI_BOTTOM_FRAC))
    roi_bbox = (y0, y1, 0, w)

    roi = frame_bgr[y0:y1, :]
    gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray, BLUR_KSIZE, 0)
    return blurred, roi_bbox


def detect_raindrops(blurred_gray: np.ndarray, baseline_gray: np.ndarray):
    """Flag pixels that deviate from the dry-baseline frame and keep only
    drop-shaped blobs (compact, roughly round, plausible size)."""
    diff = cv2.absdiff(blurred_gray, baseline_gray)
    raw_mask = (diff > DIFF_THRESH).astype(np.uint8) * 255

    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, MORPH_KSIZE)
    closed = cv2.morphologyEx(raw_mask, cv2.MORPH_CLOSE, kernel)

    n_labels, labels, stats, _ = cv2.connectedComponentsWithStats(closed, connectivity=8)
    clean_mask = np.zeros_like(closed)
    n_blobs = 0
    for i in range(1, n_labels):
        area = stats[i, cv2.CC_STAT_AREA]
        if area < MIN_BLOB_AREA:
            continue
        blob = (labels == i).astype(np.uint8)
        contours, _ = cv2.findContours(blob, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if not contours:
            continue
        perimeter = cv2.arcLength(contours[0], True)
        if perimeter == 0:
            continue
        circularity = 4 * np.pi * area / (perimeter ** 2)
        if circularity < MIN_CIRCULARITY:
            continue
        clean_mask[blob.astype(bool)] = 255
        n_blobs += 1

    return clean_mask, n_blobs


def classify_intensity(density_pct: float) -> str:
    for level, (lo, hi) in DENSITY_THRESHOLDS.items():
        if lo <= density_pct < hi:
            return level
    return "Heavy"


def run_pipeline(frame_bgr: np.ndarray, baseline_bgr: np.ndarray) -> DetectionResult:
    """Full pipeline: preprocess -> detect (vs. baseline) -> classify -> control."""
    blurred, roi_bbox = preprocess(frame_bgr)
    baseline_blurred, _ = preprocess(baseline_bgr)

    mask, n_blobs = detect_raindrops(blurred, baseline_blurred)

    density_pct = float((mask > 0).mean() * 100)
    level = classify_intensity(density_pct)
    wiper_signal = WIPER_MAP[level]

    y0, y1, x0, x1 = roi_bbox
    full_mask = np.zeros(frame_bgr.shape[:2], dtype=np.uint8)
    full_mask[y0:y1, x0:x1] = mask

    return DetectionResult(
        level=level,
        wiper_signal=wiper_signal,
        density_pct=density_pct,
        n_blobs=n_blobs,
        roi_mask=full_mask,
        roi_bbox=roi_bbox,
    )


if __name__ == "__main__":
    import sys
    img = cv2.imread(sys.argv[1])
    baseline = cv2.imread(sys.argv[2])
    res = run_pipeline(img, baseline)
    print(f"{sys.argv[1]}: level={res.level} wiper={res.wiper_signal} "
          f"density={res.density_pct:.2f}% blobs={res.n_blobs}")
