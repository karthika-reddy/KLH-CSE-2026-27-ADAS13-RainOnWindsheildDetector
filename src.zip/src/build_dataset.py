"""
Build a labeled, ground-truth rain-intensity dataset from the official
RaindropsOnWindshield sample data (Soboleva & Shipitko, 2021).

The repo ships 5 real dashcam frames, each with a "clean" version and a
version with realistic raindrops rendered on top (plus a binary mask of
exactly which pixels are raindrops). All 5 frames use the identical drop
layout, so on their own they only give us one rain level ("heavy").

To get the No Rain / Light / Moderate / Heavy spread our pipeline needs to
classify, we take each frame's connected raindrop blobs and keep a random
subset of them per level. This is fully deterministic given a seed, keeps
every pixel of every composite either exactly "clean-frame" or exactly
"real-rendered-raindrop" (no synthetic blending artifacts), and gives us
exact ground-truth masks + density values to evaluate against.
"""
import cv2
import numpy as np
import random
import json
from pathlib import Path

REPO = Path("/home/claude/repo/raindrops_generator")
OUT_FRAMES = Path("C:/Users/gcreddy/Downloads/rain_windshield_detector_project_final/data/frames")
OUT_MASKS = Path("C:/Users/gcreddy/Downloads/rain_windshield_detector_project_final/data/masks")
OUT_FRAMES.mkdir(parents=True, exist_ok=True)
OUT_MASKS.mkdir(parents=True, exist_ok=True)

FRAME_IDS = [1595, 1596, 1597, 1598, 1599]

# level name -> fraction of raindrop blobs to keep
LEVELS = {
    "no_rain": 0.0,
    "light": 0.15,
    "moderate": 0.45,
    "heavy": 1.0,
}

random.seed(42)
manifest = []

for fid in FRAME_IDS:
    clean = cv2.imread(str(REPO / f"input/seq1/{fid}.png"))
    rainy = cv2.imread(str(REPO / f"output/seq1/{fid}.png"))
    mask = cv2.imread(str(REPO / f"masks/seq1/{fid}.png"), cv2.IMREAD_GRAYSCALE)
    mask_bin = (mask > 127).astype(np.uint8)

    num_labels, labels = cv2.connectedComponents(mask_bin)
    comp_ids = list(range(1, num_labels))  # 0 = background
    random.shuffle(comp_ids)

    for level, frac in LEVELS.items():
        n_keep = round(len(comp_ids) * frac)
        keep_ids = set(comp_ids[:n_keep])
        if keep_ids:
            keep_mask = np.isin(labels, list(keep_ids))
        else:
            keep_mask = np.zeros_like(mask_bin, dtype=bool)

        composite = clean.copy()
        composite[keep_mask] = rainy[keep_mask]
        gt_mask = (keep_mask * 255).astype(np.uint8)

        density_pct = float(keep_mask.mean() * 100)

        out_name = f"{fid}_{level}"
        cv2.imwrite(str(OUT_FRAMES / f"{out_name}.png"), composite)
        cv2.imwrite(str(OUT_MASKS / f"{out_name}.png"), gt_mask)

        manifest.append({
            "id": out_name,
            "frame": fid,
            "level": level,
            "n_drops": len(keep_ids),
            "gt_density_pct": round(density_pct, 3),
        })

with open("C:/Users/gcreddy/Downloads/rain_windshield_detector_project_final/data/manifest.json", "w") as f:
    json.dump(manifest, f, indent=2)

print(f"Built {len(manifest)} labeled frames across {len(FRAME_IDS)} scenes x {len(LEVELS)} levels")
for m in manifest[:8]:
    print(m)
