import cv2
import json
import numpy as np
from pathlib import Path
from pipeline import run_pipeline

DATA = Path("C:/Users/gcreddy/Downloads/rain_windshield_detector_project_final/data")
FRAMES = DATA / "frames"
MASKS = DATA / "masks"
RESULTS = Path("C:/Users/gcreddy/Downloads/rain_windshield_detector_project_final/results")
RESULTS.mkdir(exist_ok=True)

manifest = json.load(open(DATA / "manifest.json"))

LEVEL_ORDER = ["no_rain", "light", "moderate", "heavy"]
LEVEL_DISPLAY = {"no_rain": "No Rain", "light": "Light", "moderate": "Moderate", "heavy": "Heavy"}

rows = []
correct = 0

for entry in manifest:
    fid = entry["frame"]
    level = entry["level"]
    baseline = cv2.imread(str(FRAMES / f"{fid}_no_rain.png"))
    frame = cv2.imread(str(FRAMES / f"{entry['id']}.png"))
    gt_mask = cv2.imread(str(MASKS / f"{entry['id']}.png"), cv2.IMREAD_GRAYSCALE) > 127

    res = run_pipeline(frame, baseline)
    pred_mask = res.roi_mask > 0

    tp = int((pred_mask & gt_mask).sum())
    fp = int((pred_mask & ~gt_mask).sum())
    fn = int((~pred_mask & gt_mask).sum())
    precision = tp / (tp + fp) if (tp + fp) else (1.0 if gt_mask.sum() == 0 else 0.0)
    recall = tp / (tp + fn) if (tp + fn) else 1.0
    iou = tp / (tp + fp + fn) if (tp + fp + fn) else 1.0

    is_correct = (res.level == LEVEL_DISPLAY[level])
    correct += is_correct

    rows.append({
        "id": entry["id"], "frame": fid, "true_level": LEVEL_DISPLAY[level],
        "pred_level": res.level, "correct": is_correct,
        "gt_density_pct": entry["gt_density_pct"], "pred_density_pct": round(res.density_pct, 3),
        "wiper_signal": res.wiper_signal, "n_blobs": res.n_blobs,
        "precision": round(precision, 3), "recall": round(recall, 3), "iou": round(iou, 3),
    })

acc = correct / len(rows)
mean_prec = np.mean([r["precision"] for r in rows])
mean_rec = np.mean([r["recall"] for r in rows])
mean_iou = np.mean([r["iou"] for r in rows])

print(f"{'ID':<18}{'True':<10}{'Pred':<10}{'OK':<4}{'GT%':<8}{'Pred%':<8}{'Wiper':<8}{'Prec':<7}{'Rec':<7}{'IoU':<6}")
for r in rows:
    print(f"{r['id']:<18}{r['true_level']:<10}{r['pred_level']:<10}"
          f"{'Y' if r['correct'] else 'N':<4}{r['gt_density_pct']:<8}{r['pred_density_pct']:<8}"
          f"{r['wiper_signal']:<8}{r['precision']:<7}{r['recall']:<7}{r['iou']:<6}")

print()
print(f"Level classification accuracy: {correct}/{len(rows)} = {acc*100:.1f}%")
print(f"Mean pixel precision: {mean_prec*100:.1f}%   Mean recall: {mean_rec*100:.1f}%   Mean IoU: {mean_iou*100:.1f}%")

with open(RESULTS / "evaluation.json", "w") as f:
    json.dump({
        "rows": rows,
        "accuracy": acc,
        "mean_precision": float(mean_prec),
        "mean_recall": float(mean_rec),
        "mean_iou": float(mean_iou),
    }, f, indent=2)
